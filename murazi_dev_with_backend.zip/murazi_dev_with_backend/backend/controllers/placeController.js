const Place = require('../models/Place');
const multer = require('multer');
const fs = require('fs');

// กำหนดการจัดเก็บไฟล์
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    const dir = './uploads';
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir);
    }
    cb(null, dir);
  },
  filename: function(req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage: storage });

// ดึงข้อมูลทั้งหมดพร้อมแปลงรูปภาพ
exports.getAllPlaces = async (req, res) => {
  try {
    const places = await Place.find();
    const placesWithImages = places.map(place => ({
      ...place._doc,
      bannerImage: `data:${place.bannerImage.contentType};base64,${place.bannerImage.data.toString('base64')}`
    }));
    res.json(placesWithImages);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ดึงข้อมูลตามหมวดหมู่พร้อมแปลงรูปภาพ
exports.getPlacesByCategory = async (req, res) => {
  try {
    const places = await Place.find({
      categories: req.params.category
    });
    const placesWithImages = places.map(place => ({
      ...place._doc,
      bannerImage: `data:${place.bannerImage.contentType};base64,${place.bannerImage.data.toString('base64')}`
    }));
    res.json(placesWithImages);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ดึงข้อมูลตาม ID
exports.getPlaceById = async (req, res) => {
  try {
    const place = await Place.findById(req.params.id);
    if (place) {
      res.json(place);
    } else {
      res.status(404).json({ message: 'ไม่พบสถานที่' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// เพิ่มสถานที่ใหม่พร้อมรูปภาพ
exports.createPlace = async (req, res) => {
  try {
    const place = new Place({
      name: req.body.name,
      bannerImage: {
        data: fs.readFileSync(req.file.path),
        contentType: req.file.mimetype
      },
      categories: req.body.categories,
      googleMapUrl: req.body.googleMapUrl,
      description: req.body.description
    });

    const newPlace = await place.save();
    
    // ลบไฟล์หลังจากบันทึกลง MongoDB แล้ว
    fs.unlinkSync(req.file.path);
    
    res.status(201).json(newPlace);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// แก้ไขข้อมูลสถานที่
exports.updatePlace = async (req, res) => {
  try {
    const updatedPlace = await Place.findByIdAndUpdate(
      req.params.id,
      {
        name: req.body.name,
        bannerImage: req.body.bannerImage,
        categories: req.body.categories,
        googleMapUrl: req.body.googleMapUrl,
        description: req.body.description
      },
      { new: true }
    );

    if (!updatedPlace) {
      return res.status(404).json({ message: 'ไม่พบสถานที่ที่ต้องการแก้ไข' });
    }

    res.json(updatedPlace);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};
