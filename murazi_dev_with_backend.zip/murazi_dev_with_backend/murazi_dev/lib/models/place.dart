class Place {
  final String id;
  final String name;
  final String bannerImage;
  final List<String> categories;
  final String googleMapUrl;
  final String description;
  final DateTime createdAt;

  Place({
    required this.id,
    required this.name,
    required this.bannerImage,
    required this.categories,
    required this.googleMapUrl,
    required this.description,
    required this.createdAt,
  });

  factory Place.fromJson(Map<String, dynamic> json) {
    return Place(
      id: json['_id'],
      name: json['name'],
      bannerImage: json['bannerImage'],
      categories: List<String>.from(json['categories']),
      googleMapUrl: json['googleMapUrl'],
      description: json['description'],
      createdAt: DateTime.parse(json['createdAt']),
    );
  }
}
