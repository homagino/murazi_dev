import 'package:flutter/material.dart';
import 'package:murazi_dev/models/place.dart';
import 'package:url_launcher/url_launcher.dart';

class PlaceDetailPage extends StatefulWidget {
  final Place place;

  const PlaceDetailPage({super.key, required this.place});

  @override
  _PlaceDetailPageState createState() => _PlaceDetailPageState();
}

class _PlaceDetailPageState extends State<PlaceDetailPage> {
  bool isFavorited = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(context),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildImage(),
            _buildDetails(),
          ],
        ),
      ),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      leading: IconButton(
        icon: const Icon(
          Icons.arrow_back,
          color: Colors.white,
          size: 26,
        ),
        onPressed: () => Navigator.pop(context),
      ),
      backgroundColor: const Color.fromARGB(255, 255, 0, 0),
      centerTitle: true,
      flexibleSpace: Container(
        alignment: Alignment.center,
        child: const Text(
          'MURAZI',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _buildImage() {
    return Image.network(
      widget.place.bannerImage,
      width: double.infinity,
      height: 200,
      fit: BoxFit.cover,
    );
  }

  Widget _buildDetails() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTitle(),
          _buildCategory(),
          SizedBox(height: 8),
          _buildLocationDescription(),
          SizedBox(height: 12),
          _buildDescription(),
        ],
      ),
    );
  }

  Widget _buildTitle() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            widget.place.name,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color.fromARGB(255, 255, 0, 0),
            ),
          ),
        ),
        IconButton(
          onPressed: () async {
            final Uri url = Uri.parse(widget.place.googleMapUrl);
            if (await canLaunchUrl(url)) {
              await launchUrl(url);
            }
          },
          icon: Icon(
            Icons.map,
            size: 24,
            color: const Color.fromARGB(255, 255, 0, 0),
          ),
          padding: EdgeInsets.zero,
        ),
        IconButton(
          icon: Icon(
            isFavorited ? Icons.favorite : Icons.favorite_border,
            color: const Color.fromARGB(255, 255, 0, 0),
          ),
          onPressed: () {
            setState(
              () {
                isFavorited = !isFavorited;
              },
            );
          },
        ),
      ],
    );
  }

  Widget _buildCategory() {
    return Text(
      'หมวดหมู่: ${widget.place.categories.join(", ")}',
      style: TextStyle(
        fontSize: 16,
        color: Colors.grey[600],
        fontWeight: FontWeight.bold,
      ),
    );
  }

  Widget _buildLocationDescription() {
    return Text(
      'ตำแหน่ง: ${widget.place.categories.join(", ")}',
      style: TextStyle(
        fontSize: 16,
        color: Colors.grey[600],
        fontWeight: FontWeight.bold,
      ),
    );
  }

  Widget _buildDescription() {
    return Text(
      widget.place.description,
      style: const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.bold,
      ),
    );
  }
}
