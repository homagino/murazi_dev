import 'package:flutter/material.dart';
import 'package:murazi_dev/favorite.dart';
import 'package:murazi_dev/homepage.dart';
import 'package:murazi_dev/login.dart';
import 'package:murazi_dev/notification.dart';

class UserPage extends StatefulWidget {
  @override
  _UserPageState createState() => _UserPageState();
}

class _UserPageState extends State<UserPage> {
  int _selectedIndex = 3;
  String? _selectedLanguage;
  bool _isDropdownVisible = false;

  final List<String> _languages = ['ภาษาไทย', 'English', 'Français', 'Español'];

  void _onItemTapped(int index) {
    if (index == _selectedIndex) return;

    setState(() {
      _selectedIndex = index;
    });

    Widget page;
    switch (index) {
      case 0:
        page = HomePage();
        break;
      case 1:
        page = FavoritePage();
        break;
      case 2:
        page = NotificationPage();
        break;
      case 3:
        page = UserPage();
        break;
      default:
        return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        flexibleSpace: Center(
          child: Text(
            'MURAZI',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
        backgroundColor: const Color.fromARGB(255, 255, 0, 0),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _UserProfilePhotoShow(),
            SizedBox(height: 5),
            _UserProfilePhotoChangeButton(),
            SizedBox(height: 3),
            _UserProfileNameShow(),
            SizedBox(height: 20),
            _ChangeUserDataButton(),
            SizedBox(height: 10),
            _ChangeLanguageButton(),
            _languageDropdown(),
            SizedBox(height: 10),
            _ReportButton(),
            SizedBox(height: 10),
            _logoutButton(),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _UserProfilePhotoShow() {
    return Center(
      child: Container(
        width: 200,
        height: 200,
        child: ElevatedButton(
          onPressed: () {},
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: const Color.fromARGB(255, 255, 0, 0),
            padding: EdgeInsets.zero,
          ),
          child: Text(
            'Profile',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _UserProfilePhotoChangeButton() {
    return Center(
      child: Container(
        width: 120,
        height: 30,
        child: TextButton(
          onPressed: () {},
          style: TextButton.styleFrom(
            foregroundColor: const Color.fromARGB(255, 255, 0, 0),
            padding: EdgeInsets.zero,
          ),
          child: Text(
            'เปลี่ยนรูปภาพ',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _UserProfileNameShow() {
    return Center(
      child: Text(
        'Firstname Surname',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.bold,
          color: const Color.fromARGB(255, 255, 0, 0),
        ),
      ),
    );
  }

  Widget _ChangeUserDataButton() {
    return Center(
      child: Container(
        width: 280,
        height: 50,
        child: ElevatedButton(
          onPressed: () {},
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: const Color.fromARGB(255, 255, 0, 0),
            padding: EdgeInsets.zero,
          ),
          child: Text(
            'เปลี่ยนข้อมูลผู้ใช้งาน',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _ChangeLanguageButton() {
    return Center(
      child: Container(
        width: 280,
        height: 50,
        child: ElevatedButton(
          onPressed: () {
            setState(() {
              _isDropdownVisible = !_isDropdownVisible;
            });
          },
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: const Color.fromARGB(255, 255, 0, 0),
            padding: EdgeInsets.zero,
          ),
          child: Text(
            'เปลี่ยนภาษา',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _languageDropdown() {
    return Visibility(
      visible: _isDropdownVisible,
      child: Container(
        width: 150,
        child: DropdownButton<String>(
          value: _selectedLanguage,
          hint: Text('เลือกภาษา'),
          isExpanded: true,
          items: _languages.map((String language) {
            return DropdownMenuItem<String>(
              value: language,
              child: Container(
                height: 40,
                child: Text(
                  language,
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
              ),
            );
          }).toList(),
          onChanged: (String? newValue) {
            setState(() {
              _selectedLanguage = newValue;
              _isDropdownVisible = false;
            });
          },
        ),
      ),
    );
  }

  Widget _ReportButton() {
    return Center(
      child: Container(
        width: 280,
        height: 50,
        child: ElevatedButton(
          onPressed: () {},
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: const Color.fromARGB(255, 255, 0, 0),
            padding: EdgeInsets.zero,
          ),
          child: Text(
            'แจ้งปัญหา',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _logoutButton() {
    return Center(
      child: Container(
        width: 280,
        height: 50,
        child: ElevatedButton(
          onPressed: () {
            _showLogoutConfirmationDialog();
          },
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: const Color.fromARGB(255, 255, 0, 0),
            padding: EdgeInsets.zero,
          ),
          child: Text(
            'ออกจากระบบ',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  void _showLogoutConfirmationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async {
            return false;
          },
          child: AlertDialog(
            title: Text(
              'ยืนยันการออกจากระบบ',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
            content: Text(
              'คุณต้องการออกจากระบบหรือไม่?',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 255, 0, 0),
              ),
            ),
            actions: <Widget>[
              TextButton(
                style: TextButton.styleFrom(
                  foregroundColor: const Color.fromARGB(255, 255, 255, 255),
                  backgroundColor: const Color.fromARGB(255, 255, 17, 0),
                ),
                child: Text('ไม่'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              TextButton(
                style: TextButton.styleFrom(
                  foregroundColor: const Color.fromARGB(255, 255, 255, 255),
                  backgroundColor: const Color.fromARGB(255, 255, 17, 0),
                ),
                child: Text('ใช่'),
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => LoginPage()),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      items: const <BottomNavigationBarItem>[
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'หน้าหลัก',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.favorite),
          label: 'สถานที่ถูกใจ',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.notifications),
          label: 'การแจ้งเตือน',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person),
          label: 'ข้อมูลผู้ใช้',
        ),
      ],
      currentIndex: _selectedIndex,
      selectedItemColor: const Color.fromARGB(255, 255, 0, 0),
      unselectedItemColor: const Color.fromARGB(255, 255, 0, 0),
      onTap: _onItemTapped,
    );
  }
}
